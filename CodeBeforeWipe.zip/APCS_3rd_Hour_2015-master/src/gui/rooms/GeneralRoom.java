package rooms;

public class GeneralRoom extends Room
{

	public GeneralRoom(String[] data, int id) 
	{
		super(data, id);
	}

}
