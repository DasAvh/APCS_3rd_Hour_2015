package rooms;

public class PassageRoom extends Room
{
	//Fields
	private PassageRoom teleport;
	
	public PassageRoom(String[] data, int id) 
	{
		super(data, id);
	}

	public void setTeleport(PassageRoom otherRoom)
	{
		
	}
}//End
