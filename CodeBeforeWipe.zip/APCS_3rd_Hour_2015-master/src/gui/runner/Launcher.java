package runner;

public class Launcher 
{
	public static void main(String[] args)
	{
		Game window = new Game("Gamma", 800, 600);
		window.start();
	}//End main
}//End Launcher class
