package states;

import java.awt.Graphics;

import runner.Game;

public class SettingsState extends State
{

	public SettingsState(Game game) {
		super(game);
	}

	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(Graphics g) {
		// TODO Auto-generated method stub
		
	}

}
