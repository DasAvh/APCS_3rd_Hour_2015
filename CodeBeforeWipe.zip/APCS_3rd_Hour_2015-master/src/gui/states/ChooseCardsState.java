package states;

import java.awt.Graphics;

import runner.Game;

public class ChooseCardsState extends State 
{
	//Fields
	
	public ChooseCardsState(Game game) 
	{
		super(game);
	}

	@Override
	public void tick() 
	{
		
	}//End tick method

	@Override
	public void render(Graphics g) 
	{
	
	}//End render method
}//End ChooseCardsState

