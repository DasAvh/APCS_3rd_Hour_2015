package tiles;

import graphics.Assets;

public class WallTile extends Tile 
{
	public WallTile(int id)
	{
		super(Assets.wall, id);
	}//End constructor
}//End class WallTile
