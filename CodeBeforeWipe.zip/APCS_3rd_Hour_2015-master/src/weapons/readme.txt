Weahpowns have two values, isMurderWeapon(boolean) and weaponPicture(Image) isMurderWeapon says if it is the
murder weapon, at the beginning of the game someone(whoever is responsible for implementing these weapons) needs
to randomly find one weapon to make the murder weapon.  An array of Weapons should be used, and when initialized
it should contain one of each subclass of weapon.  the subclasses' default constructors set the images for the 
weapons. everything else that could be needed is in the weapon class and is public.
