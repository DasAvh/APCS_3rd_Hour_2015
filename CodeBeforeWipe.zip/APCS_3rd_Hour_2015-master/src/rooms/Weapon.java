
public class Weapon {

}
